# DOAS-005 Digital Twin — Blue Frontier LD-DOAS

Interactive 3D digital twin for the Blue Frontier LD-DOAS unit deployed at **Von's/Albertsons, Gardena CA**.

- **Model:** BFLDD1806SSB0SS
- **Serial:** 2515AG2C2R2S2001
- **Voltage:** 480V / 3ph / 60Hz
- **Capacity:** 15 Ton (180,000 BTU)

## Features

- **Dual 3D Sketchfab Models** — Official Blue Frontier CAD models by Dinier Quiros
  - Closed (exterior) view for Overview mode
  - Open (exposed internals) view when exploring subsystems
  - Automatic swap with crossfade transition
  - Manual toggle via 🔒/🔓 button
- **4 Explorable Subsystems** with live sensor data:
  - ❄ **Conditioner Core** — 3-channel HMX, blowers, dampers, desiccant pump, water valves
  - 🔥 **Regenerator** — Compressor, heat pump, regen blower/pump, refrigerant pressures
  - 🛢 **Storage Tanks** — SOD concentration, tank level, thresholds visualization
  - ⚡ **Controls** — ECY-600 PLC setpoints, power/water consumption, alarm status
- **Simulated Real-Time Data** — Refreshes every 2.5s with realistic sensor jitter
  - Uses actual EC-GFX point names (C_BL1_Speed, Tank_SOD, R_PT1, etc.)
  - Ready to swap for live API endpoint
- **Sparkline Trends** — Power draw, supply air temp, desiccant concentration
- **Full 360° Orbit** — Drag, scroll-zoom, right-click pan via Sketchfab viewer

## Prerequisites

- **Node.js** v16 or higher — [Download here](https://nodejs.org/)
- **npm** (comes with Node.js)

To check if you have them:
```bash
node --version
npm --version
```

## Quick Start

### 1. Install dependencies
```bash
cd doas-twin-v3
npm install
```

This will take 1-2 minutes on first run (downloads React and build tools).

### 2. Start the development server
```bash
npm start
```

Your browser will automatically open to **http://localhost:3000** with the digital twin running full-screen.

### 3. Interact
- **Drag** to orbit the 3D model
- **Scroll** to zoom in/out
- **Right-click drag** to pan
- Click **subsystem buttons** at the bottom to open panels and swap to the internal view
- Click **🔒/🔓** in the top bar to manually toggle closed/open views

## Build for Production

To create an optimized build for deployment on a web server or customer dashboard:

```bash
npm run build
```

This outputs a `build/` folder containing static files you can host anywhere:
- Any web server (Apache, Nginx)
- Netlify, Vercel, GitHub Pages
- Embed in an existing dashboard via iframe

## Project Structure

```
doas-twin-v3/
├── public/
│   └── index.html          # HTML shell
├── src/
│   ├── index.js             # React entry point
│   └── App.js               # Main digital twin component
├── package.json             # Dependencies & scripts
└── README.md                # This file
```

Everything is in a single `App.js` file by design — makes it easy to read, modify, and understand the full system.

## Connecting Live Sensor Data

The simulated data engine is the `useSensors()` hook at the top of `App.js`. To connect real data:

### Option A: REST API (Grafana, custom endpoint)
Replace the `useSensors` hook's `setInterval` with a `fetch`:

```javascript
useEffect(() => {
  const tick = async () => {
    const res = await fetch('https://your-api.com/doas-005/sensors');
    const live = await res.json();
    setD(/* map live data to the same shape */);
  };
  tick();
  const id = setInterval(tick, 5000);
  return () => clearInterval(id);
}, []);
```

### Option B: WebSocket (real-time streaming)
```javascript
useEffect(() => {
  const ws = new WebSocket('wss://your-api.com/doas-005/stream');
  ws.onmessage = (e) => {
    const live = JSON.parse(e.data);
    setD(/* map to shape */);
  };
  return () => ws.close();
}, []);
```

### Option C: Teltonika Proxy
If routing through the Teltonika RMS proxy for DOAS-005:
```
https://0364ce0f42d99eec3e868f247902ce6c.proxy1-connect.rms.teltonika-networks.com
```

## Sketchfab API Enhancement

If your team provides a Sketchfab API token (from the Blue Frontier account), you can unlock:

- **Node manipulation** — `api.getNodeMap()` to show/hide individual components
- **3D annotations** — Pin sensor labels directly to coordinates on the model
- **Camera presets** — Programmatic camera positions for each subsystem
- **Material changes** — Color components by alarm state (green=normal, red=alarm)

## Sketchfab Model UIDs

| View   | UID                                | Link |
|--------|------------------------------------|------|
| Closed | `dc7bdeaef60d4c6d9f9e5370eaaaeaee` | [Sketchfab](https://sketchfab.com/3d-models/blue-frontier-closed-dc7bdeaef60d4c6d9f9e5370eaaaeaee) |
| Open   | `486fd8794ed84881a3fc23d87ab0d354` | [Sketchfab](https://sketchfab.com/3d-models/blue-frontier-ld-doas-486fd8794ed84881a3fc23d87ab0d354) |

Both models by **Dinier Quiros** / Blue Frontier official account.

## Fleet Reference

This twin is configured for DOAS-005 but can be adapted for any unit in the fleet by changing the unit metadata and sensor mappings. See the Blue Frontier Fleet Registry skill for all deployed unit details.

---

*Built by BLUE — Blue Frontier AI Platform | February 2026*
